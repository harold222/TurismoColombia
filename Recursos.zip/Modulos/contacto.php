<br>

<form id="formulario" action="Config/Correo.php" method="post" class="contactos" onsubmit="return validarFormulario();">
    <h2 class="mejor">Contactanos</h2>
    <input type="text" name="nombre" id="nombre" placeholder="Nombre" >
    <input type="text" name="correo" id="correo" placeholder="Correo" >
    <input type="text" name="telefono" id="telefono" placeholder="Telefono">
    <textarea name="mensaje" id="mensaje" placeholder="Escriba su mensaje" ></textarea>
    <input type="submit" value="Enviar mensaje" id="botonContact">
</form>
<br>
